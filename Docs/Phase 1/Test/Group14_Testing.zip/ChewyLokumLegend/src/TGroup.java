
public class TGroup {
	
	public TGroup(){
		
	}
	
	public int[][] checkTGroup(Board board){
		// Pre-condition: Two lokums that wanted to be swapped are adjacent.

		// @requires: board != null 
			       
		// Post-condition: Exit of the procedure
		// @ensures: if any Tgroup is formed, they are detected.
				                  
	
		int[][] TGroup = null;
		
		return TGroup;
	}

}
