import java.util.Random;

import Model.BrownHazelnutLokum;
import Model.GreenPistachioLokum;
import Model.RedRoseLokum;
import Model.RegularLokum;
import Model.WhiteCoconutLokum;


public class GameEngine {
	
	private Integer score;
	private Integer level;
	private Board board;
	Random random = new Random();
	
	public GameEngine(){
		this.board = new Board(10,6);
	}
	
	/**
	 * 
	 * @return Lokum : randomly generated lokum
	 */
	public RegularLokum generateRegularLokum(){
	 /**
	  * Pre-condition: Entry to the procedure by a call from the procedures fillEmptySpaces or populateBoard
	  * 
	  * @requires:  score != null	&&	board != null	&&	level != null
	  * 
	  * Post-condition: Exit of the procedure			 
	  * 
	  * @ensures:  score != null    &&	board != null   && level != null
	  * 		 Score, board and level remains same.
	  * 		 A random Lokum object is created.
	  * 
	  * @modifies: 
	  * 
	  * 
	  */
		int lokumType = random.nextInt(4);
		RegularLokum lokum;
		switch (lokumType) {
        case 0:  lokum = new BrownHazelnutLokum(0,0);
                 break;
        case 1:  lokum = new RedRoseLokum(0,0);
                 break;
        case 2:  lokum = new WhiteCoconutLokum(0,0);
                 break;
        case 3:  lokum = new GreenPistachioLokum(0,0);
                 break;
        default: lokum = null;
        		 break;
		}
		return lokum;
	}
	
	public void fillEmptySpaces(){
		/**
		 * Pre-condition: Entry to the procedure
		 * 
		 * @requires: score != null && board != null && level != null
		 * 
		 * Post-condition: Exit to the procedure
		 * 
		 * @ensures: score != null && board != null && level != null
		 * 			Score and level remains same.
		 * 			Board's empty spaces filled with new randomly generated lokums.
		 * 
		 * @modifies: board
		 * 	
		 */
//		for(int i=this.board.getBoardObjects().length-1; i>=0; i--){
//			for(int j=0; j<this.board.getBoardObjects()[0].length; j++){
//				if(this.board.getBoardObjects()[i][j].getType() == 4 && i != 0){
//					
//						if(this.board.getBoardObjects()[i-1][j].getType() != 3){
//							this.board.getBoardObjects()[i][j] = this.board.getBoardObjects()[i-1][j];
//						}
//					
//				}
//			}
//		}
	}
	
	public void populateBoard(){
		/**
		* Pre-condition: Entry to the procedure
		* 
		* @requires: score != null && board == null && level != null
		* 
		* Post-condition: Exit to the procedure
		* 
		* @ensures: score != null && board != null && level != null
		* 			Score and level remains same.
		* 			All board is filled with new randomly generated lokums.
		* 
		* @modifies: board
		* 	
		*/
		for(int i=0; i<this.board.getBoardObjects().length; i++){
			for(int j=0; j<this.board.getBoardObjects()[0].length; j++){
				RegularLokum lokum = generateRegularLokum();
				lokum.setRow(i);
				lokum.setColumn(j);
				board.putObject(lokum);
			}
		}
	}
	
	public void saveGame(){
		/**
		 * Pre-condition: Entry to the procedure
		 * 
		 * @reqires: score != null	&&	board != null	&&	level != null 
		 * 	
		 * Post-condition: Exit of the procedure
		 * 
		 * @ensures:  score != null    &&	board != null   && level != null
		 * 			Score, board and level won't be changed until the game is loaded.
		 * 
		 * @modifies: 
		 * 
		 */
			
			
		}
	
	public Board getBoard(){
		return board;
	}

}
