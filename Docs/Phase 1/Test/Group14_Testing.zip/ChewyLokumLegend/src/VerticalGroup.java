
public class VerticalGroup {
	
	public VerticalGroup(){
		
	}
	
	public int[] checkVerticalGroup(Board board){
		// Pre-condition: Two lokums that wanted to be swapped are adjacent.

		// @requires: board != null 
			       
		// Post-condition: Exit of the procedure
		// @ensures: If any vertical group is formed, their information is returned.
		int[] verticalGroups = null;
		
		return verticalGroups;
	}

}
