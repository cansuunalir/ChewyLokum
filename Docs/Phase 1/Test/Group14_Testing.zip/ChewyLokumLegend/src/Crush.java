


public class Crush {

	private Board board;
	
	public Crush(Board board){
		super();
		this.board = board;
	}
	
	
	public void crushVertical(int column){
	 
	//Pre-condition:Call to procedure from Game Engine 
	//				Two lokums must have been swapped in vertical direction
	//
	//@requires: column < board[0].length
	//			 
	//Post-condition: The given column of the board is updated.
	//				  board[i][column]=0;	
	//				  
	//@ensures: Each index in given column is set to null.
	//		
	//				
	//@modifies: this.board is modified 
		
	//	for(int i=0; i<board.length(); i++){
	//		board[i][column]=0;
	//	}
		
					
		
	}
	
	public void crushHorizontal(int row){
		//Pre-condition: Two lokums must have been swapped in horizontal direction
		//
		//@requires: column < board.length
		//			 
		//Post-condition: The given row of the board is updated.
		//				  
		//@ensures: Each index in given row is set to null.
		//				
		//@modifies: this.board is modified 
		//
		//
		//	for(int i=0; i<board[0].length(); i++){
		//		board[row][i]=0;
		//	}
		
	}
	
	public void crushColor(int color){
		//Pre-condition: Colorbomb lokum must have been swapped 
		//
		//@requires: color = lokum2.color()
		//			 
		//			 
		//Post-condition: Each lokum object on board with color=lokum2.color() is 
		//				  converted into null
		//				  
		//@ensures: Only objects with given color are crashed
		//				
		//@modifies: this.board is modified 
		
	}
	
	public void crushArea(int row, int column){
		//Pre-condition: Colorbomb lokum must have been swapped 
		//
		//@requires: row = board.getObject().getRow && 
		//			 column = board.getObject().getColumn
		//			 
		//Post-condition: Area around to colorbomb between [row-1] and [row+1]
		//				  && [column-1] and [column+1] are set to 0.
		//				  
		//@ensures: Onyl the area around colorbomb is set to 0.
		//				
		//@modifies: this.board is modified 
	}
}
