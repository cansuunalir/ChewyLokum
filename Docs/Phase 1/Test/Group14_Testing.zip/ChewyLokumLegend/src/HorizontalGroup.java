
public class HorizontalGroup {
	
	public HorizontalGroup(){
		
	}
	
	public int[] checkHorizontalGroup(Board board){
		// Pre-condition: Two lokums that wanted to be swapped are adjacent.

		// @requires: board != null 
			       
		// Post-condition: Exit of the procedure
		// @ensures: If any horizontal group is formed, their information is returned.
		int[] horizontalGroups = null;
		
		return horizontalGroups;
	}

}
