package Model;

public class ColorBombLokum extends SpecialLokum {

	public ColorBombLokum(int row, int column) {
		super(row, column);
	}

}
