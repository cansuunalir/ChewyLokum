package Model;

public class BrownHazelnutLokum extends RegularLokum {

	public BrownHazelnutLokum(int row, int column) {
		super(row, column);
		super.setColor(0);
	}

}
