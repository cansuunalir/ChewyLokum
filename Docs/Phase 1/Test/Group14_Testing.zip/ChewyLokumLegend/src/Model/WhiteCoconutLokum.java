package Model;

public class WhiteCoconutLokum extends RegularLokum {

	public WhiteCoconutLokum(int row, int column) {
		super(row, column);
		super.setColor(2);
	}

}
