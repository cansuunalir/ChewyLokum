package Model;

public abstract class RegularLokum extends BoardObject {
	
	private Integer color;

	public RegularLokum(int row, int column) {
		super(row, column);
		super.setType(1);
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}
	
	public String toString(){
		return super.toString() + " Color:" + color;
	}
	
	public boolean repOK(){
		super.repOK();
		if(color == null)
			return false;
		return true;
	}

}
