package Model;

public class WrappedLokum extends SpecialLokum {
	
	private Integer color;

	public WrappedLokum(int row, int column, int color) {
		super(row, column);
		this.color = color;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}
	
	public String toString(){
		return super.toString() + " Color:" + color;
	}
	
	public boolean repOK(){
		super.repOK();
		if(color == null)
			return false;
		return true;
	}

}
