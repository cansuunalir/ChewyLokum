package Model;

public class GreenPistachioLokum extends RegularLokum {

	public GreenPistachioLokum(int row, int column) {
		super(row, column);
		super.setColor(3);
	}

}
