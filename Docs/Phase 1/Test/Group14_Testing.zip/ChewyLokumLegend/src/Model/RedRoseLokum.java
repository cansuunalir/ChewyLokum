package Model;

public class RedRoseLokum extends RegularLokum {

	public RedRoseLokum(int row, int column) {
		super(row, column);
		super.setColor(1);
	}

}
