package Model;

public class StripedLokum extends SpecialLokum {
	
	private Integer color;
	private boolean orientation;

	public StripedLokum(int row, int column, int color, boolean orientation) {
		super(row, column);
		this.color = color;
		this.orientation = orientation;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public boolean isOrientation() {
		return orientation;
	}

	public void setOrientation(boolean orientation) {
		this.orientation = orientation;
	}
	
	public String toString(){
		return super.toString() + " Color:" + color + " Orientation:" + orientation;
	}
	
	public boolean repOK(){
		super.repOK();
		if(color == null)
			return false;
		return true;
	}

}
